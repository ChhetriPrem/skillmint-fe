function injectMintBadgeButton() {
  if (!location.hostname.endsWith("github.com")) return;
  if (document.getElementById("mint-badge-extension-btn")) return;

  const btn = document.createElement("button");
  btn.id = "mint-badge-extension-btn";
  btn.innerHTML = "🏅 Mint Badge"; // You can replace the emoji with an SVG icon if desired

  // Enhanced button styles
  Object.assign(btn.style, {
    position: "fixed",
    top: "20px",
    right: "24px",
    zIndex: 10000,
    padding: "12px 24px",
    background: "linear-gradient(90deg, #2da44e 0%, #238636 100%)",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    boxShadow: "0 4px 16px rgba(34, 197, 94, 0.15)",
    fontSize: "17px",
    fontWeight: "600",
    fontFamily: "inherit",
    cursor: "pointer",
    letterSpacing: "0.02em",
    outline: "none",
    transition: "background 0.2s, box-shadow 0.2s, transform 0.1s",
    display: "flex",
    alignItems: "center",
    gap: "8px",
  });

  // Hover and active effects using CSS
  btn.addEventListener("mouseenter", () => {
    btn.style.background = "linear-gradient(90deg, #238636 0%, #2da44e 100%)";
    btn.style.boxShadow = "0 6px 24px rgba(34, 197, 94, 0.25)";
    btn.style.transform = "translateY(-2px) scale(1.03)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "linear-gradient(90deg, #2da44e 0%, #238636 100%)";
    btn.style.boxShadow = "0 4px 16px rgba(34, 197, 94, 0.15)";
    btn.style.transform = "none";
  });
  btn.addEventListener("mousedown", () => {
    btn.style.transform = "scale(0.97)";
  });
  btn.addEventListener("mouseup", () => {
    btn.style.transform = "translateY(-2px) scale(1.03)";
  });

  document.body.appendChild(btn);

  btn.addEventListener("click", () => {
    // Parse the URL: https://github.com/{owner}/{repo}/pull/{number}
    const url = window.location.href;
    const match = url.match(/github\.com\/([^\/]+)\/([^\/]+)(\/pull\/(\d+))?/);
    if (!match) return;

    const owner = match[1];
    const repo = match[2];
    const prNumber = match[4] || "";

    // Save info to storage, then open the popup
    chrome.runtime.sendMessage(
      {
        action: "githubInfo",
        owner,
        repo,
        prNumber,
        url,
      },
      () => {
        if (chrome.action && chrome.action.openPopup) {
          chrome.action.openPopup();
        }
      }
    );
  });
}
