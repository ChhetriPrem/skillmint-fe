function injectMintBadgeButton() {
  if (!location.hostname.endsWith("github.com")) return;
  if (document.getElementById("mint-badge-extension-btn")) return;

  const btn = document.createElement("button");
  btn.id = "mint-badge-extension-btn";
  btn.textContent = "Mint Badge";

  // Improved button styles (color, shape, hover, shadow)
  btn.style.position = "fixed";
  btn.style.top = "16px";
  btn.style.right = "16px";
  btn.style.zIndex = 10000;
  btn.style.padding = "12px 28px";
  btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)"; // purple to green
  btn.style.color = "#fff";
  btn.style.border = "none";
  btn.style.borderRadius = "8px";
  btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
  btn.style.fontSize = "17px";
  btn.style.fontWeight = "600";
  btn.style.fontFamily = "inherit";
  btn.style.cursor = "pointer";
  btn.style.letterSpacing = "0.04em";
  btn.style.transition = "background 0.2s, box-shadow 0.2s, transform 0.1s";

  // Simple hover effect
  btn.addEventListener("mouseenter", () => {
    btn.style.background = "linear-gradient(90deg, #2da44e 0%, #238636 100%)"; // brighter green
    btn.style.boxShadow = "0 6px 24px rgba(34,197,94,0.25)";
    btn.style.transform = "translateY(-2px) scale(1.03)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)";
    btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
    btn.style.transform = "none";
  });

  document.body.appendChild(btn);

  btn.addEventListener("click", () => {
    const url = window.location.href;
    const match = url.match(/github\.com\/([^\/]+)\/([^\/]+)(\/pull\/(\d+))?/);
    if (!match) return;

    const owner = match[1];
    const repo = match[2];
    const prNumber = match[4] || "";

    chrome.runtime.sendMessage(
      {
        action: "githubInfo",
        owner,
        repo,
        prNumber,
        url,
      },
      () => {
        if (chrome.action && chrome.action.openPopup) {
          chrome.action.openPopup();
        }
      }
    );
  });
}
function injectMintBadgeButton() {
  if (!location.hostname.endsWith("github.com")) return;
  if (document.getElementById("mint-badge-extension-btn")) return;

  const btn = document.createElement("button");
  btn.id = "mint-badge-extension-btn";
  btn.textContent = "Mint Badge";

  // Improved button styles (color, shape, hover, shadow)
  btn.style.position = "fixed";
  btn.style.top = "16px";
  btn.style.right = "16px";
  btn.style.zIndex = 10000;
  btn.style.padding = "12px 28px";
  btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)"; // purple to green
  btn.style.color = "#fff";
  btn.style.border = "none";
  btn.style.borderRadius = "8px";
  btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
  btn.style.fontSize = "17px";
  btn.style.fontWeight = "600";
  btn.style.fontFamily = "inherit";
  btn.style.cursor = "pointer";
  btn.style.letterSpacing = "0.04em";
  btn.style.transition = "background 0.2s, box-shadow 0.2s, transform 0.1s";

  // Simple hover effect
  btn.addEventListener("mouseenter", () => {
    btn.style.background = "linear-gradient(90deg, #2da44e 0%, #238636 100%)"; // brighter green
    btn.style.boxShadow = "0 6px 24px rgba(34,197,94,0.25)";
    btn.style.transform = "translateY(-2px) scale(1.03)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)";
    btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
    btn.style.transform = "none";
  });

  document.body.appendChild(btn);

  btn.addEventListener("click", () => {
    const url = window.location.href;
    const match = url.match(/github\.com\/([^\/]+)\/([^\/]+)(\/pull\/(\d+))?/);
    if (!match) return;

    const owner = match[1];
    const repo = match[2];
    const prNumber = match[4] || "";

    chrome.runtime.sendMessage(
      {
        action: "githubInfo",
        owner,
        repo,
        prNumber,
        url,
      },
      () => {
        if (chrome.action && chrome.action.openPopup) {
          chrome.action.openPopup();
        }
      }
    );
  });
}
function injectMintBadgeButton() {
  if (!location.hostname.endsWith("github.com")) return;
  if (document.getElementById("mint-badge-extension-btn")) return;

  const btn = document.createElement("button");
  btn.id = "mint-badge-extension-btn";
  btn.textContent = "Mint Badge";

  // Improved button styles (color, shape, hover, shadow)
  btn.style.position = "fixed";
  btn.style.top = "16px";
  btn.style.right = "16px";
  btn.style.zIndex = 10000;
  btn.style.padding = "12px 28px";
  btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)"; // purple to green
  btn.style.color = "#fff";
  btn.style.border = "none";
  btn.style.borderRadius = "8px";
  btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
  btn.style.fontSize = "17px";
  btn.style.fontWeight = "600";
  btn.style.fontFamily = "inherit";
  btn.style.cursor = "pointer";
  btn.style.letterSpacing = "0.04em";
  btn.style.transition = "background 0.2s, box-shadow 0.2s, transform 0.1s";

  // Simple hover effect
  btn.addEventListener("mouseenter", () => {
    btn.style.background = "linear-gradient(90deg, #2da44e 0%, #238636 100%)"; // brighter green
    btn.style.boxShadow = "0 6px 24px rgba(34,197,94,0.25)";
    btn.style.transform = "translateY(-2px) scale(1.03)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)";
    btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
    btn.style.transform = "none";
  });

  document.body.appendChild(btn);

  btn.addEventListener("click", () => {
    const url = window.location.href;
    const match = url.match(/github\.com\/([^\/]+)\/([^\/]+)(\/pull\/(\d+))?/);
    if (!match) return;

    const owner = match[1];
    const repo = match[2];
    const prNumber = match[4] || "";

    chrome.runtime.sendMessage(
      {
        action: "githubInfo",
        owner,
        repo,
        prNumber,
        url,
      },
      () => {
        if (chrome.action && chrome.action.openPopup) {
          chrome.action.openPopup();
        }
      }
    );
  });
}
function injectMintBadgeButton() {
  if (!location.hostname.endsWith("github.com")) return;
  if (document.getElementById("mint-badge-extension-btn")) return;

  const btn = document.createElement("button");
  btn.id = "mint-badge-extension-btn";
  btn.textContent = "Mint Badge";

  // Improved button styles (color, shape, hover, shadow)
  btn.style.position = "fixed";
  btn.style.top = "16px";
  btn.style.right = "16px";
  btn.style.zIndex = 10000;
  btn.style.padding = "12px 28px";
  btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)"; // purple to green
  btn.style.color = "#fff";
  btn.style.border = "none";
  btn.style.borderRadius = "8px";
  btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
  btn.style.fontSize = "17px";
  btn.style.fontWeight = "600";
  btn.style.fontFamily = "inherit";
  btn.style.cursor = "pointer";
  btn.style.letterSpacing = "0.04em";
  btn.style.transition = "background 0.2s, box-shadow 0.2s, transform 0.1s";

  // Simple hover effect
  btn.addEventListener("mouseenter", () => {
    btn.style.background = "linear-gradient(90deg, #2da44e 0%, #238636 100%)"; // brighter green
    btn.style.boxShadow = "0 6px 24px rgba(34,197,94,0.25)";
    btn.style.transform = "translateY(-2px) scale(1.03)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)";
    btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
    btn.style.transform = "none";
  });

  document.body.appendChild(btn);

  btn.addEventListener("click", () => {
    const url = window.location.href;
    const match = url.match(/github\.com\/([^\/]+)\/([^\/]+)(\/pull\/(\d+))?/);
    if (!match) return;

    const owner = match[1];
    const repo = match[2];
    const prNumber = match[4] || "";

    chrome.runtime.sendMessage(
      {
        action: "githubInfo",
        owner,
        repo,
        prNumber,
        url,
      },
      () => {
        if (chrome.action && chrome.action.openPopup) {
          chrome.action.openPopup();
        }
      }
    );
  });
}
function injectMintBadgeButton() {
  if (!location.hostname.endsWith("github.com")) return;
  if (document.getElementById("mint-badge-extension-btn")) return;

  const btn = document.createElement("button");
  btn.id = "mint-badge-extension-btn";
  btn.textContent = "Mint Badge";

  // Improved button styles (color, shape, hover, shadow)
  btn.style.position = "fixed";
  btn.style.top = "16px";
  btn.style.right = "16px";
  btn.style.zIndex = 10000;
  btn.style.padding = "12px 28px";
  btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)"; // purple to green
  btn.style.color = "#fff";
  btn.style.border = "none";
  btn.style.borderRadius = "8px";
  btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
  btn.style.fontSize = "17px";
  btn.style.fontWeight = "600";
  btn.style.fontFamily = "inherit";
  btn.style.cursor = "pointer";
  btn.style.letterSpacing = "0.04em";
  btn.style.transition = "background 0.2s, box-shadow 0.2s, transform 0.1s";

  // Simple hover effect
  btn.addEventListener("mouseenter", () => {
    btn.style.background = "linear-gradient(90deg, #2da44e 0%, #238636 100%)"; // brighter green
    btn.style.boxShadow = "0 6px 24px rgba(34,197,94,0.25)";
    btn.style.transform = "translateY(-2px) scale(1.03)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)";
    btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
    btn.style.transform = "none";
  });

  document.body.appendChild(btn);

  btn.addEventListener("click", () => {
    const url = window.location.href;
    const match = url.match(/github\.com\/([^\/]+)\/([^\/]+)(\/pull\/(\d+))?/);
    if (!match) return;

    const owner = match[1];
    const repo = match[2];
    const prNumber = match[4] || "";

    chrome.runtime.sendMessage(
      {
        action: "githubInfo",
        owner,
        repo,
        prNumber,
        url,
      },
      () => {
        if (chrome.action && chrome.action.openPopup) {
          chrome.action.openPopup();
        }
      }
    );
  });
}
function injectMintBadgeButton() {
  if (!location.hostname.endsWith("github.com")) return;
  if (document.getElementById("mint-badge-extension-btn")) return;

  const btn = document.createElement("button");
  btn.id = "mint-badge-extension-btn";
  btn.textContent = "Mint Badge";

  // Improved button styles (color, shape, hover, shadow)
  btn.style.position = "fixed";
  btn.style.top = "16px";
  btn.style.right = "16px";
  btn.style.zIndex = 10000;
  btn.style.padding = "12px 28px";
  btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)"; // purple to green
  btn.style.color = "#fff";
  btn.style.border = "none";
  btn.style.borderRadius = "8px";
  btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
  btn.style.fontSize = "17px";
  btn.style.fontWeight = "600";
  btn.style.fontFamily = "inherit";
  btn.style.cursor = "pointer";
  btn.style.letterSpacing = "0.04em";
  btn.style.transition = "background 0.2s, box-shadow 0.2s, transform 0.1s";

  // Simple hover effect
  btn.addEventListener("mouseenter", () => {
    btn.style.background = "linear-gradient(90deg, #2da44e 0%, #238636 100%)"; // brighter green
    btn.style.boxShadow = "0 6px 24px rgba(34,197,94,0.25)";
    btn.style.transform = "translateY(-2px) scale(1.03)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)";
    btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
    btn.style.transform = "none";
  });

  document.body.appendChild(btn);

  btn.addEventListener("click", () => {
    const url = window.location.href;
    const match = url.match(/github\.com\/([^\/]+)\/([^\/]+)(\/pull\/(\d+))?/);
    if (!match) return;

    const owner = match[1];
    const repo = match[2];
    const prNumber = match[4] || "";

    chrome.runtime.sendMessage(
      {
        action: "githubInfo",
        owner,
        repo,
        prNumber,
        url,
      },
      () => {
        if (chrome.action && chrome.action.openPopup) {
          chrome.action.openPopup();
        }
      }
    );
  });
}
function injectMintBadgeButton() {
  if (!location.hostname.endsWith("github.com")) return;
  if (document.getElementById("mint-badge-extension-btn")) return;

  const btn = document.createElement("button");
  btn.id = "mint-badge-extension-btn";
  btn.textContent = "Mint Badge";

  // Improved button styles (color, shape, hover, shadow)
  btn.style.position = "fixed";
  btn.style.top = "16px";
  btn.style.right = "16px";
  btn.style.zIndex = 10000;
  btn.style.padding = "12px 28px";
  btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)"; // purple to green
  btn.style.color = "#fff";
  btn.style.border = "none";
  btn.style.borderRadius = "8px";
  btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
  btn.style.fontSize = "17px";
  btn.style.fontWeight = "600";
  btn.style.fontFamily = "inherit";
  btn.style.cursor = "pointer";
  btn.style.letterSpacing = "0.04em";
  btn.style.transition = "background 0.2s, box-shadow 0.2s, transform 0.1s";

  // Simple hover effect
  btn.addEventListener("mouseenter", () => {
    btn.style.background = "linear-gradient(90deg, #2da44e 0%, #238636 100%)"; // brighter green
    btn.style.boxShadow = "0 6px 24px rgba(34,197,94,0.25)";
    btn.style.transform = "translateY(-2px) scale(1.03)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "linear-gradient(90deg, #6f42c1 0%, #2da44e 100%)";
    btn.style.boxShadow = "0 4px 16px rgba(34,197,94,0.18)";
    btn.style.transform = "none";
  });

  document.body.appendChild(btn);

  btn.addEventListener("click", () => {
    const url = window.location.href;
    const match = url.match(/github\.com\/([^\/]+)\/([^\/]+)(\/pull\/(\d+))?/);
    if (!match) return;

    const owner = match[1];
    const repo = match[2];
    const prNumber = match[4] || "";

    chrome.runtime.sendMessage(
      {
        action: "githubInfo",
        owner,
        repo,
        prNumber,
        url,
      },
      () => {
        if (chrome.action && chrome.action.openPopup) {
          chrome.action.openPopup();
        }
      }
    );
  });
}
